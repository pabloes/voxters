(<any>engine)["RESOURCE_BASE"] = "metas/voxterspet/";
import Meta from './meta';

export const VoxtersPet = Meta.default;